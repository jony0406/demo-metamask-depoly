export const tokens = {
    "0x33f90dee07c6e8b9682dd20f73e6c358b2ed0f03": {
      "address": "0x33f90dee07c6e8b9682dd20f73e6c358b2ed0f03",
      "symbol": "TRDT",
      "decimals": 18,
      "unlisted": false
    },
    "0x39013f961c378f02c2b82a6e1d31e9812786fd9d": {
      "address": "0x39013f961c378f02c2b82a6e1d31e9812786fd9d",
      "symbol": "SMS",
      "decimals": 18,
      "unlisted": false
    },
    "0x78b7fada55a64dd895d8c8c35779dd8b67fa8a05": {
      "address": "0x78b7fada55a64dd895d8c8c35779dd8b67fa8a05",
      "symbol": "ATL",
      "decimals": 18,
      "unlisted": false
    },
    "0xfd8971d5e8e1740ce2d0a84095fca4de729d0c16": {
      "address": "0xfd8971d5e8e1740ce2d0a84095fca4de729d0c16",
      "symbol": "ZLA",
      "decimals": 18,
      "unlisted": false
    },
    "0xe83cccfabd4ed148903bf36d4283ee7c8b3494d1": {
      "address": "0xe83cccfabd4ed148903bf36d4283ee7c8b3494d1",
      "symbol": "BTT",
      "decimals": 18,
      "unlisted": false
    },
    "0x7a07e1a0c2514d51132183ecfea2a880ec3b7648": {
      "address": "0x7a07e1a0c2514d51132183ecfea2a880ec3b7648",
      "symbol": "IXE",
      "decimals": 18,
      "unlisted": false
    },
    "0x467Bccd9d29f223BcE8043b84E8C8B282827790F": {
      "address": "0x467Bccd9d29f223BcE8043b84E8C8B282827790F",
      "symbol": "TEL",
      "decimals": 18,
      "unlisted": false
    },
    "0xff20817765cb7f73d4bde2e66e067e58d11095c2": {
      "address": "0xff20817765cb7f73d4bde2e66e067e58d11095c2",
      "symbol": "AMP",
      "decimals": 18,
      "unlisted": false
    },
    "0x15bda08c3afbf5955d6e9b235fd55a1fd0dbc829": {
      "address": "0x15bda08c3afbf5955d6e9b235fd55a1fd0dbc829",
      "symbol": "APC",
      "decimals": 18,
      "unlisted": false
    },
  }