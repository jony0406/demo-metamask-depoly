import { addons } from '@storybook/addons';
import MetaMaskStorybookTheme from './metamask-storybook-theme';

addons.setConfig({
  theme: MetaMaskStorybookTheme,
});
