export enum EtherDenomination {
  ETH = 'ETH',
  GWEI = 'GWEI',
  WEI = 'WEI',
}
