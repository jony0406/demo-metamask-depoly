export enum ThemeType {
  light = 'light',
  dark = 'dark',
  os = 'os',
}
