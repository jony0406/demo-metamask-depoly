export const isMain = process.env.METAMASK_BUILD_TYPE === 'main';
export const isFlask = process.env.METAMASK_BUILD_TYPE === 'flask';
