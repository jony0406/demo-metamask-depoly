declare module 'human-standard-token-abi';
