# MetaMask Design System

A design system is a series of components that can be reused in different combinations. Design systems allow you to manage design at scale.

Design System [Figma File](https://www.figma.com/file/HKpPKij9V3TpsyMV1TpV7C/DS-Components?node-id=401%3A2122&t=oqaI3NKZ059Vo67h-1)
