# Confirmation Pages Refactoring

The document details about refactoring confirmation pages. It describes the current code and improved proposed architecture.

1. [Signature Request Pages](https://github.com/MetaMask/metamask-extension/tree/develop/docs/refactoring/signature-request)

2. [Confirmation Pages Routing](https://github.com/MetaMask/metamask-extension/tree/develop/docs/refactoring/confirmation-pages-routing)
