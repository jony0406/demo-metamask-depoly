import { testsForProviderType } from './provider-api-tests/shared-tests';

describe('createInfuraClient', () => {
  testsForProviderType('infura');
});
