import * as React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';

const appElement = document.querySelector('#app');

ReactDOM.render(<App />, appElement);
